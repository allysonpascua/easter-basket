//
//  MainViewController.h
//  Allyson Change
//
//  Created by Keck Lab User on 9/20/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FlipsideViewController.h"

@interface MainViewController : UIViewController <FlipsideViewControllerDelegate> {
	//UILabel *outputLabel;
	
	UILabel *outputFromCoins;
	UILabel *outputQuarters;
	UILabel *outputDimes;
	UILabel *outputNickels;
	UILabel *outputPennies;
	UITextField *inputChange;
	
//	UIImageView *imageQuarter;
}

//@property (nonatomic, retain) IBOutlet UILabel *outputLabel;
@property (nonatomic, retain) IBOutlet UILabel *outputFromCoins;
@property (nonatomic, retain) IBOutlet UILabel *outputQuarters;
@property (nonatomic, retain) IBOutlet UILabel *outputDimes;
@property (nonatomic, retain) IBOutlet UILabel *outputNickels;
@property (nonatomic, retain) IBOutlet UILabel *outputPennies;
@property (nonatomic, retain) IBOutlet UITextField *inputChange;

//@property (nonatomic, retain) IBOutlet UIImageView *imageQuarter;


// If this were Java, the above line would be equivalent to:
//
//     public UILabel getOutputLabel();
//     public void setOutputLabel(UILabel outputLabel);


- (IBAction)showInfo:(id)sender;
- (IBAction)makeChange:(id)sender;
//- (IBAction)quarter;

// In C-like syntax, the above looks like:
//     [public] IBAction makeChange(id sender);
// (if hooks to UI are removed...)
//     void makeChange(void *sender);

@end
