//
//  MainViewController.m
//  Allyson Change
//
//  Created by Keck Lab User on 9/20/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MainViewController.h"


@implementation MainViewController

@synthesize inputChange;
//@synthesize outputLabel;
@synthesize outputFromCoins;
@synthesize outputQuarters;
@synthesize outputDimes;
@synthesize outputNickels;
@synthesize outputPennies;

//@synthesize imageQuarter;


// In Java, this is equivalent to:
//
// public UILabel getOutputLabel() {
//     return outputLabel;
// }
//
// public void setOutputLabel(UILabel outputLabel) {
//     this.outputLabel = outputLabel;
// }


/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	[super viewDidLoad];
}
*/


- (void)flipsideViewControllerDidFinish:(FlipsideViewController *)controller {
    
	[self dismissModalViewControllerAnimated:YES];
}


- (IBAction)showInfo:(id)sender {    
	
	FlipsideViewController *controller = [[FlipsideViewController alloc] initWithNibName:@"FlipsideView" bundle:nil];
	controller.delegate = self;
	
	controller.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
	[self presentModalViewController:controller animated:YES];
	
	[controller release];
}


- (IBAction)makeChange:(id)sender {
	NSInteger inputValue = [inputChange.text intValue];
	
	// In Java, the intValue call would have looked like:
	//     inputChange.text.intValue();

	NSInteger remainder;
	
	
	remainder = inputValue % 25;
	NSInteger quarters = (inputValue - (remainder))/25;
	//remainder = remainder % 10;
	NSInteger dimes = (remainder - (remainder % 10))/10;
	remainder = remainder % 10;
	NSInteger nickels = (remainder - (remainder % 5))/5;
	NSInteger pennies = remainder % 5;
	
	
	//outputLabel.text = [NSString stringWithFormat:@"From %d coins, you can make\n%d Quarters \n%d Dimes \n%d Nickels \n%d Pennies.", inputValue, quarters, dimes, nickels, pennies];
	[inputChange resignFirstResponder];
	
	
	outputFromCoins.text = [NSString stringWithFormat:@"From %d coins, you can make", inputValue];
	outputQuarters.text = [NSString stringWithFormat:@"%d", quarters];
	outputDimes.text = [NSString stringWithFormat:@"%d", dimes];
	outputNickels.text = [NSString stringWithFormat:@"%d", nickels];
	outputPennies.text = [NSString stringWithFormat:@"%d", pennies];
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc. that aren't in use.
}


- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations.
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


- (void)dealloc {
    [super dealloc];
}


@end
